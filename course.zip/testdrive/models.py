from django.contrib.auth.models import User
from django.db import models
from auto.models import Vehicle
from django.utils import timezone


class Testdrive(models.Model):
    vehicle = models.ForeignKey(Vehicle)
    user = models.ForeignKey(User)
    date_created = models.DateTimeField(default=timezone.now)
    date_completed = models.DateField(null=True, blank=True)
