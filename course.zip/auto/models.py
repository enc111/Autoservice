from django.db import models


class Mark(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Model(models.Model):
    name = models.CharField(max_length=100)
    mark = models.ForeignKey(Mark)

    def __str__(self):
        return '{} {}'.format(self.mark, self.name)


class Dealer(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    country = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Vehicle(models.Model):
    COMPLECTATION_BASE = 'base'
    COMPLECTATION_INTERMEDIATE = 'intermediate'
    COMPLECTATION_MAX = 'max'
    COMPLECTATION_CHOICES = (
        (COMPLECTATION_BASE, 'Base'),
        (COMPLECTATION_INTERMEDIATE, 'Intermediate'),
        (COMPLECTATION_MAX, 'Max'),
    )
    price = models.DecimalField(decimal_places=2, max_digits=12)
    description = models.TextField()
    color = models.CharField(max_length=100)
    complectation = models.CharField(max_length=25, choices=COMPLECTATION_CHOICES)
    model = models.ForeignKey(Model)
    dealer = models.ForeignKey(Dealer)
    year_of_manufacture = models.IntegerField()#for check up

    def __int__(self):
        return self.year_of_manufacture

    def __str__(self):
        return '{} ({})'.format(self.model, self.complectation)
