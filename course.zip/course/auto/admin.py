from django.contrib import admin
from auto.models import Mark, Model, Vehicle, Dealer


admin.site.register(Mark)
admin.site.register(Model)
admin.site.register(Dealer)
admin.site.register(Vehicle)
