from django.db import models


class Checkup(models.Model):
    pass