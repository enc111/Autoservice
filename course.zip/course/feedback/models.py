from django.db import models
from django.contrib.auth.models import User

class Comment(models.Model):
    text = models.TextField()
    user = models.ForeignKey(User)
