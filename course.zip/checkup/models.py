from datetime import timezone
from django.contrib.auth.models import User
from django.db import models
from auto.models import Vehicle


class Checkup(models.Model):
    date_created = models.DateTimeField(default=timezone.now)
    date_completed = models.DateField(null=True, blank=True)
    reg_number = models.CharField(max_length=15)
    run = models.IntegerField()
    year_of_manufacture = models.ForeignKey(Vehicle)
    user = models.ForeignKey(User)
    type_of_service = models.ForeignKey(TypeOfService)


class TypeOfService():
    name = models.CharField(max_length=100)
    price = models.DecimalField(decimal_places=2, max_digits=12)